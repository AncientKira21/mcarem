package com.ancientkira.mca.fabric;

import com.ancientkira.mca.PlatformHelper;
import net.fabricmc.loader.api.FabricLoader;

public class FabricPlatformHelper extends PlatformHelper {
    @Override
    protected boolean isModLoadedUncached(String namespace) {
        return FabricLoader.getInstance().isModLoaded(namespace);
    }

    @Override
    public boolean isDevelopmentEnvironment() {
        return FabricLoader.getInstance().isDevelopmentEnvironment();
    }
}
