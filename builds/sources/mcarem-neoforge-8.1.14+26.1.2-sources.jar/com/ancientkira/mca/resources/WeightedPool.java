package com.ancientkira.mca.resources;

import java.util.ArrayList;
import java.util.List;

public class WeightedPool<T> {

    protected final List<WeightedPool.Entry<T>> entries = new ArrayList<>();
    private final T defaultValue;

    public WeightedPool(T defaultValue) {
        this.defaultValue = defaultValue;
    }

    public T pickOne() {
        double totalChance = entries.stream().mapToDouble(a -> a.weight).sum() * API.getRng().nextDouble();

        for (WeightedPool.Entry<T> e : entries) {
            totalChance -= e.weight;
            if (totalChance <= 0.0) {
                return e.value;
            }
        }
        return defaultValue;
    }

    public T pickNext(T current, int next) {
        if (entries.isEmpty()) {
            return defaultValue;
        }

        //look for the current one
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).value.equals(current)) {
                return entries.get(Math.floorMod(i + next, entries.size())).value;
            }
        }

        //fallback
        return entries.get(next < 0 ? entries.size() - 1 : 0).value;
    }

    public List<Entry<T>> getEntries() {
        return entries;
    }

    public static class Entry<T> {
        private final T value;
        private final float weight;

        public Entry(T value, float weight) {
            this.value = value;
            this.weight = weight;
        }

        public T getValue() {
            return value;
        }

        public float getWeight() {
            return weight;
        }
    }

    public static class Mutable<T> extends WeightedPool<T> {

        public Mutable(T defaultValue) {
            super(defaultValue);
        }

        public void add(T value, float weight) {
            entries.add(new WeightedPool.Entry<>(value, weight));
        }
    }
}
