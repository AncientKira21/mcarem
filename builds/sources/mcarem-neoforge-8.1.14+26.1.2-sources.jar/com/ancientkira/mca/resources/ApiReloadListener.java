package com.ancientkira.mca.resources;

import com.ancientkira.mca.MCA;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;

public class ApiReloadListener implements ResourceManagerReloadListener {
    public static final Identifier ID = MCA.locate("api");

    @Override
    public void onResourceManagerReload(ResourceManager manager) {
        API.instance = new API.Data();
        API.instance.init(manager);
    }
}
