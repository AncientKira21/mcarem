package com.ancientkira.mca.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.ancientkira.mca.entity.VillagerEntityMCA;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.npc.villager.Villager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;

@Mixin(Zombie.class)
public abstract class MixinZombie {
    @WrapOperation(
            method = "killedEntity(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/damagesource/DamageSource;)Z",
            constant = @Constant(classValue = Villager.class, ordinal = 0)
    )
    private boolean mca$excludeMcaVillagersFromVanillaConversion(
            Object entity,
            Operation<Boolean> original
    ) {
        return original.call(entity) && !(entity instanceof VillagerEntityMCA);
    }
}
