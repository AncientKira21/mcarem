package com.ancientkira.mca.mixin;

import com.ancientkira.mca.entity.VillagerLike;
import com.ancientkira.mca.entity.ai.Traits;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Item.class)
public class MixinMilkBucketItem {
    @Inject(method = "finishUsingItem", at = @At("RETURN"))
    public void mca$injectFinishUsingItem(ItemStack stack, Level world, LivingEntity user, CallbackInfoReturnable<ItemStack> cir) {
        if (!stack.is(Items.MILK_BUCKET) || world.isClientSide()) {
            return;
        }
        VillagerLike<?> villagerLike = VillagerLike.toVillager(user);
        if (villagerLike != null) {
            if (villagerLike.getTraits().hasTrait(Traits.LACTOSE_INTOLERANCE)) {
                user.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
            }
        }
    }
}

