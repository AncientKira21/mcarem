package com.ancientkira.mca.network.c2s;

import com.ancientkira.mca.MCA;
import com.ancientkira.mca.entity.VillagerEntityMCA;
import com.ancientkira.mca.entity.VillagerLike;
import com.ancientkira.mca.entity.ai.relationship.Gender;
import com.ancientkira.mca.network.HandleablePayload;
import com.ancientkira.mca.network.Network;
import com.ancientkira.mca.network.s2c.GetVillagerResponse;
import com.ancientkira.mca.network.s2c.PlayerDataMessage;
import com.ancientkira.mca.resources.SkinVisualIds;
import com.ancientkira.mca.resources.data.skin.LayeredHair;
import com.ancientkira.mca.server.world.data.FamilyTree;
import com.ancientkira.mca.server.world.data.FamilyTreeNode;
import com.ancientkira.mca.server.world.data.PlayerSaveData;
import com.ancientkira.mca.util.NbtHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.core.UUIDUtil;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.villager.VillagerProfession;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public record VillagerEditorSyncRequest(String command, UUID uuid, CompoundTag data) implements HandleablePayload {
    private static final String[] MCA_VISUAL_KEYS = {
            "Gender",
            "Clothes",
            "ClothingLocked",
            "Skin",
            "Hair",
            "HairStyle",
            "HairBase",
            "HairBangs",
            "HairBack",
            "HairFront",
            "HairExtra",
            "SkinColor",
            "HairColor",
            "EyeColor",
            "EyeColorLeft",
            "AgeState",
            "PlayerModel"
    };

    public static final CustomPacketPayload.Type<VillagerEditorSyncRequest> TYPE = new CustomPacketPayload.Type<>(MCA.locate("villager_editor_sync_request"));
    public static final StreamCodec<FriendlyByteBuf, VillagerEditorSyncRequest> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, VillagerEditorSyncRequest::command,
            UUIDUtil.STREAM_CODEC, VillagerEditorSyncRequest::uuid,
            ByteBufCodecs.COMPOUND_TAG, VillagerEditorSyncRequest::data,
            VillagerEditorSyncRequest::new
    );

    public VillagerEditorSyncRequest {
        data = data.copy();
    }

    public static boolean isAllowedTopLevelKey(String key) {
        return key.equals("Age") ||
               key.equals("CustomName") ||
               key.equals("CustomNameVisible") ||
               key.equals("FamilyTreeNewFatherName") ||
               key.equals("FamilyTreeNewMotherName") ||
               key.equals("FamilyTreeNewSpouseName") ||
               key.equals("VillagerDataFinalized");
    }

    public static boolean isAllowedMcaKey(String key) {
        if (key.startsWith("Gene")) {
            return true;
        }
        if (key.equals("Personality") || key.equals("Traits")) {
            return true;
        }
        for (String visualKey : MCA_VISUAL_KEYS) {
            if (visualKey.equals(key)) {
                return true;
            }
        }
        if (key.equals("HairDye") || key.equals("SkinDye") || key.equals("EyeDye") || key.equals("EyeLeftDye")) {
            return true;
        }
        if (key.equals("InfectionProgress") || key.equals("Mood") || key.equals("Memories")) {
            return true;
        }
        return false;
    }

    public static CompoundTag createEditorPatch(CompoundTag sourceNbt) {
        CompoundTag patch = new CompoundTag();
        for (String key : sourceNbt.keySet()) {
            if (isAllowedTopLevelKey(key)) {
                patch.put(key, Objects.requireNonNull(sourceNbt.get(key)).copy());
            }
        }

        CompoundTag mcaPatch = new CompoundTag();
        for (String key : sourceNbt.keySet()) {
            if (isAllowedMcaKey(key)) {
                mcaPatch.put(key, Objects.requireNonNull(sourceNbt.get(key)).copy());
            }
        }

        sourceNbt.getCompound("MCAData").ifPresent(sourceMca -> {
            for (String key : sourceMca.keySet()) {
                if (isAllowedMcaKey(key)) {
                    mcaPatch.put(key, Objects.requireNonNull(sourceMca.get(key)).copy());
                }
            }
        });

        if (!mcaPatch.isEmpty()) {
            patch.put("MCAData", mcaPatch);
        }
        return patch;
    }

    public static CompoundTag mergeAllowedEditorPatch(CompoundTag serverData, CompoundTag patch) {
        CompoundTag merged = serverData.copy();
        for (String key : patch.keySet()) {
            if (isAllowedTopLevelKey(key)) {
                merged.put(key, Objects.requireNonNull(patch.get(key)).copy());
            }
        }

        patch.getCompound("MCAData").ifPresent(patchMca -> {
            CompoundTag mergedMca = NbtHelper.getOrCreateCompound(merged, "MCAData");
            for (String key : patchMca.keySet()) {
                if (isAllowedMcaKey(key)) {
                    mergedMca.put(key, Objects.requireNonNull(patchMca.get(key)).copy());
                }
            }
        });

        // Defensive preservation:
        String[] preservedKeys = {"Offers", "Gossips", "Inventory", "VillagerXp", "UUID", "UUIDMost", "UUIDLeast"};
        for (String key : preservedKeys) {
            if (serverData.contains(key)) {
                merged.put(key, Objects.requireNonNull(serverData.get(key)).copy());
            } else {
                merged.remove(key);
            }
        }
        return merged;
    }

    public CompoundTag data() {
        return data.copy();
    }

    @Override
    public void handleServer(ServerPlayer player) {
        Entity entity = player.level().getEntity(uuid);
        switch (command) {
            case "skin", "hair", "layered_hair", "hair_base", "hair_bangs", "hair_back", "hair_front", "hair_extra", "clothing", "gender", "sync" ->
                    saveEntity(player, entity, data());
            case "profession" -> {
                if (entity instanceof VillagerEntityMCA villager) {
                    VillagerProfession profession = BuiltInRegistries.VILLAGER_PROFESSION.getValue(Identifier.parse(data.getString("profession").orElse("minecraft:none")));
                    villager.setProfession(profession);
                }
            }
        }
    }

    private void saveEntity(ServerPlayer player, Entity entity, CompoundTag patch) {
        if (entity == null) {
            return;
        }

        if (entity instanceof ServerPlayer serverPlayer) {
            CompoundTag serverData = PlayerSaveData.get(serverPlayer).getEntityData();
            CompoundTag merged = mergeAllowedEditorPatch(serverData, patch);
            PlayerSaveData data = PlayerSaveData.get(serverPlayer);
            data.setEntityData(merged);
            data.setEntityDataSet(true);
            syncFamilyTree(player, entity, merged);
            serverPlayer.level().players().forEach(p -> Network.sendToPlayer(new PlayerDataMessage(serverPlayer.getUUID(), merged), p));
            Network.sendToPlayer(new GetVillagerResponse(merged), player);
            return;
        }

        if (entity instanceof VillagerLike<?> villagerLike) {
            CompoundTag serverData = GetVillagerRequest.getVillagerData(entity);
            if (serverData == null) {
                return;
            }

            CompoundTag merged = mergeAllowedEditorPatch(serverData, patch);
            sanitizeVisualIdentifiers(entity, merged);

            villagerLike.syncFromEditor(merged);
            entity.refreshDimensions();
            syncFamilyTree(player, entity, merged);

            if (entity instanceof VillagerEntityMCA villager) {
                villager.getResidency().getHomeVillage().ifPresent(b -> b.updateResident(villager));
            }

            CompoundTag fresh = GetVillagerRequest.getVillagerData(entity);
            Network.sendToPlayer(new GetVillagerResponse(fresh != null ? fresh : merged), player);
        }
    }

    private void sanitizeVisualIdentifiers(Entity entity, CompoundTag villagerData) {
        CompoundTag mcaData = normalizeVisualData(villagerData);
        migrateLegacyHairStyle(mcaData);
        CompoundTag fallbackData = GetVillagerRequest.getVillagerData(entity);
        CompoundTag fallbackMcaData = fallbackData == null ? new CompoundTag() : getMcaData(fallbackData);
        Gender gender = getGender(villagerData);
        clearInvalidIdentifier(mcaData, fallbackMcaData, "Skin", identifier -> SkinVisualIds.isBodySkin(identifier, gender));
        clearInvalidIdentifier(mcaData, fallbackMcaData, "Clothes", identifier -> SkinVisualIds.isClothing(identifier, gender));
        clearInvalidIdentifier(mcaData, fallbackMcaData, "Hair", identifier -> SkinVisualIds.isHairStyle(identifier, gender));
        clearInvalidIdentifier(mcaData, fallbackMcaData, "HairStyle", identifier -> SkinVisualIds.isHairStyle(identifier, gender));
        for (LayeredHair.Category category : LayeredHair.Category.values()) {
            clearInvalidIdentifier(mcaData, fallbackMcaData, category.getDataKey(), identifier -> SkinVisualIds.isHairLayer(identifier, category, gender));
        }
    }

    private void migrateLegacyHairStyle(CompoundTag mcaData) {
        String hairStyle = mcaData.getString("HairStyle").orElse("");
        if (SkinVisualIds.isLegacyHairTexture(hairStyle)) {
            mcaData.putString("HairBase", hairStyle);
            mcaData.putString("HairStyle", "");
            mcaData.putString("Hair", "");
        }
    }

    private CompoundTag normalizeVisualData(CompoundTag villagerData) {
        CompoundTag mcaData = getOrCreateMcaData(villagerData);
        for (String key : MCA_VISUAL_KEYS) {
            if (!mcaData.contains(key) && villagerData.contains(key)) {
                mcaData.put(key, Objects.requireNonNull(villagerData.get(key)).copy());
            }
            villagerData.remove(key);
        }
        return mcaData;
    }

    private void clearInvalidIdentifier(CompoundTag mcaData, CompoundTag fallbackMcaData, String key, Predicate<String> validator) {
        String identifier = mcaData.getString(key).orElse("");
        if (!MCA.isBlankString(identifier) && !validator.test(identifier)) {
            MCA.LOGGER.warn("Ignoring unknown villager editor visual identifier {}={}", key, identifier);
            String fallback = fallbackMcaData.getString(key).orElse("");
            mcaData.putString(key, !MCA.isBlankString(fallback) && validator.test(fallback) ? fallback : "");
        }
    }

    private Gender getGender(CompoundTag villagerData) {
        CompoundTag mcaData = getMcaData(villagerData);
        if (mcaData.contains("Gender")) {
            return Gender.byId(mcaData.getInt("Gender").orElse(0));
        }
        if (villagerData.contains("Gender")) {
            return Gender.byId(villagerData.getInt("Gender").orElse(0));
        }
        return Gender.UNASSIGNED;
    }

    private CompoundTag getMcaData(CompoundTag villagerData) {
        return NbtHelper.getCompoundOrSelf(villagerData, VillagerEntityMCA.MCA_DATA_KEY);
    }

    private CompoundTag getOrCreateMcaData(CompoundTag villagerData) {
        boolean hadMcaData = villagerData.getCompound(VillagerEntityMCA.MCA_DATA_KEY).isPresent();
        CompoundTag mcaData = NbtHelper.getOrCreateCompound(villagerData, VillagerEntityMCA.MCA_DATA_KEY);
        if (!hadMcaData) {
            for (String key : MCA_VISUAL_KEYS) {
                if (villagerData.contains(key)) {
                    mcaData.put(key, Objects.requireNonNull(villagerData.get(key)).copy());
                }
            }
        }
        return mcaData;
    }

    private Optional<FamilyTreeNode> getFamilyNode(ServerPlayer player, FamilyTree tree, String name, Gender gender) {
        try {
            UUID uuid = UUID.fromString(name);
            Optional<FamilyTreeNode> node = tree.getOrEmpty(uuid);
            if (node.isPresent()) {
                player.sendSystemMessage(Component.translatable("gui.villager_editor.uuid_known", name, node.get().getName()));
                return node;
            } else {
                player.sendSystemMessage(Component.translatable("gui.villager_editor.uuid_unknown", name).withStyle(ChatFormatting.RED));
                return Optional.empty();
            }
        } catch (IllegalArgumentException exception) {
            List<FamilyTreeNode> nodes = tree.getAllWithName(name).toList();
            if (nodes.isEmpty()) {
                player.sendSystemMessage(Component.translatable("gui.villager_editor.name_created", name).withStyle(ChatFormatting.YELLOW));
                return Optional.of(tree.getOrCreate(UUID.randomUUID(), name, gender));
            } else {
                if (nodes.size() > 1) {
                    player.sendSystemMessage(Component.translatable("gui.villager_editor.name_not_unique", name).withStyle(ChatFormatting.RED));

                    String uuids = nodes.stream().map(FamilyTreeNode::id).map(UUID::toString).collect(Collectors.joining(", "));
                    player.sendSystemMessage(Component.translatable("gui.villager_editor.list_of_ids", uuids));
                } else {
                    player.sendSystemMessage(Component.translatable("gui.villager_editor.name_unique", name));
                }

                return Optional.ofNullable(nodes.getFirst());
            }
        }
    }

    private void syncFamilyTree(ServerPlayer player, Entity entity, CompoundTag villagerData) {
        FamilyTree tree = FamilyTree.get((ServerLevel) entity.level());
        FamilyTreeNode entry = tree.getOrCreate(entity);
        entry.setGender(getGender(villagerData));

        VillagerLike.parseCustomName(entity.registryAccess(), villagerData)
                .map(Component::getString)
                .ifPresent(entry::setName);

        if (villagerData.contains("FamilyTreeNewFatherName")) {
            String name = villagerData.getString("FamilyTreeNewFatherName").orElse("");
            if (MCA.isBlankString(name)) {
                entry.removeFather();
            } else {
                getFamilyNode(player, tree, name, Gender.MALE).ifPresent(entry::setFather);
            }
        }

        if (villagerData.contains("FamilyTreeNewMotherName")) {
            String name = villagerData.getString("FamilyTreeNewMotherName").orElse("");
            if (MCA.isBlankString(name)) {
                entry.removeMother();
            } else {
                getFamilyNode(player, tree, name, Gender.FEMALE).ifPresent(entry::setMother);
            }
        }

        if (villagerData.contains("FamilyTreeNewSpouseName")) {
            String name = villagerData.getString("FamilyTreeNewSpouseName").orElse("");
            if (MCA.isBlankString(name)) {
                Optional.of(entry.partner()).flatMap(tree::getOrEmpty).ifPresent(node -> node.updatePartner(null, null));
                entry.updatePartner(null, null);
            } else {
                getFamilyNode(player, tree, name, entry.gender().opposite()).ifPresent(node -> {
                    entry.updatePartner(node);
                    node.updatePartner(entry);
                });
            }
        }
    }

    @Override
    public Type<VillagerEditorSyncRequest> type() {
        return TYPE;
    }
}
