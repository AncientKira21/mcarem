package com.ancientkira.mca.neoforge;

import com.ancientkira.mca.MCA;
import com.ancientkira.mca.block.BlockEntityTypesMCA;
import com.ancientkira.mca.entity.ai.ActivitiesMCA;
import com.ancientkira.mca.entity.ai.MemoryModuleTypeMCA;
import com.ancientkira.mca.entity.ai.SchedulesMCA;
import com.ancientkira.mca.entity.ai.SensorsMCA;
import com.ancientkira.mca.entity.interaction.gifts.GiftLoader;
import com.ancientkira.mca.network.HandleablePayload;
import com.ancientkira.mca.network.MessagesMCA;
import com.ancientkira.mca.network.Network;
import com.ancientkira.mca.registry.*;
import com.ancientkira.mca.resources.*;
import com.ancientkira.mca.server.ServerInteractionManager;
import com.ancientkira.mca.server.command.AdminCommand;
import com.ancientkira.mca.server.command.Command;
import com.ancientkira.mca.server.world.data.VillageManager;
import com.ancientkira.mca.util.network.datasync.MCAEntityDataSerializers;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import net.neoforged.neoforge.event.AddServerReloadListenersEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.RegisterEvent;

import java.util.function.Consumer;

@Mod(MCA.MOD_ID)
@EventBusSubscriber(modid = MCA.MOD_ID)
public final class CommonNeoForge {
    static {
        MCA.platformHelper = new NeoforgePlatformHelper();
    }

    private static <T> void registerHelper(RegisterEvent event, Registry<T> register, Consumer<MCA.RegisterHelper<T>> consumer) {
        event.register(register.key(), registry -> consumer.accept(registry::register));
    }

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        if (event.getRegistryKey() == NeoForgeRegistries.Keys.ENTITY_DATA_SERIALIZERS) {
            event.register(NeoForgeRegistries.Keys.ENTITY_DATA_SERIALIZERS, helper -> {
                helper.register(MCAEntityDataSerializers.COMPOUND_TAG_ID, MCAEntityDataSerializers.COMPOUND_TAG);
                helper.register(MCAEntityDataSerializers.OPTIONAL_UUID_ID, MCAEntityDataSerializers.OPTIONAL_UUID);
            });
        }

        registerHelper(event, BuiltInRegistries.ITEM, ItemsMCA::registerItems);
        registerHelper(event, BuiltInRegistries.BLOCK, BlocksMCA::registerBlocks);
        registerHelper(event, BuiltInRegistries.SOUND_EVENT, SoundsMCA::registerSounds);
        registerHelper(event, BuiltInRegistries.PARTICLE_TYPE, ParticleTypesMCA::registerParticles);
        registerHelper(event, BuiltInRegistries.ENTITY_TYPE, EntitiesMCA::registerEntities);
        registerHelper(event, BuiltInRegistries.SENSOR_TYPE, SensorsMCA::registerSensors);
        registerHelper(event, BuiltInRegistries.ACTIVITY, ActivitiesMCA::registerActivities);
        registerHelper(event, BuiltInRegistries.MEMORY_MODULE_TYPE, MemoryModuleTypeMCA::registerTypes);
        registerHelper(event, BuiltInRegistries.ENVIRONMENT_ATTRIBUTE, SchedulesMCA::registerSchedules);
        registerHelper(event, BuiltInRegistries.VILLAGER_PROFESSION, ProfessionsMCA::registerProfessions);
        registerHelper(event, BuiltInRegistries.DATA_COMPONENT_TYPE, DataComponentsMCA::registerProfessions);
        registerHelper(event, BuiltInRegistries.TRIGGER_TYPES, CriterionMCA::registerCriteria);

        if (event.getRegistryKey() == Registries.BLOCK_ENTITY_TYPE) {
            event.register(Registries.BLOCK_ENTITY_TYPE, helper ->
                    BlockEntityTypesMCA.registerBlockEntityTypes((name, factory, block) -> {
                        //noinspection DataFlowIssue
                        BlockEntityType<?> build = new BlockEntityType<>(factory::create, block);
                        helper.register(name, build);
                        return build;
                    }));
        }

        if (event.getRegistryKey() == Registries.CREATIVE_MODE_TAB) {
            CreativeModeTab tab = CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.mca.mca_tab"))
                    .icon(() -> new ItemStack(ItemsMCA.ENGAGEMENT_RING))
                    .withTabsBefore(CreativeModeTabs.SPAWN_EGGS)
                    .displayItems((params, output) -> {
                        for (Item item : ItemsMCA.ITEMS.values()) {
                            output.accept(new ItemStack(item));
                        }
                    })
                    .build();
            event.register(Registries.CREATIVE_MODE_TAB, helper -> helper.register(MCA.locate("mca_tab"), tab));
        }
    }

    @SubscribeEvent
    public static void onAddReloadListener(AddServerReloadListenersEvent event) {
        event.addListener(MCA.locate("api"), new ApiReloadListener());
        event.addListener(MCA.locate("body_skins"), new BodySkinList());
        event.addListener(MCA.locate("clothing"), new ClothingList());
        event.addListener(MCA.locate("hair_styles"), new HairStyleList());
        event.addListener(MCA.locate("layered_hair"), new LayeredHairList());
        event.addListener(MCA.locate("gifts"), new GiftLoader());
        event.addListener(MCA.locate("dialogues"), new Dialogues());
        event.addListener(MCA.locate("tasks"), new Tasks());
        event.addListener(MCA.locate("names"), new Names());
        event.addListener(MCA.locate("building_types"), new BuildingTypes());
    }

    @SubscribeEvent
    public static void onCommandRegister(RegisterCommandsEvent event) {
        AdminCommand.register(event.getDispatcher());
        Command.register(event.getDispatcher());
    }

    @SubscribeEvent
    public static void onWorldTick(LevelTickEvent.Post event) {
        if (event.getLevel() instanceof ServerLevel serverLevel) {
            VillageManager.get(serverLevel).tick();
        }
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        ServerInteractionManager.getInstance().tick();
        MCA.setServer(event.getServer());
    }

    @SubscribeEvent
    public static void onPlayerLoggedInEvent(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ServerInteractionManager.getInstance().onPlayerJoin(player);
        }
    }

    @SubscribeEvent
    public static void createDefaultAttributes(EntityAttributeCreationEvent event) {
        EntitiesMCA.registerAttributes((type, supplier) -> event.put(type, supplier.build()));
    }

    @SubscribeEvent
    public static void registerNetwork(final RegisterPayloadHandlersEvent event) {
        MessagesMCA.register(new NeoForgeRegistrar(event.registrar("1")));
        Network.registerSender(PacketDistributor::sendToPlayer);
        Network.registerClientSender(ClientPacketDistributor::sendToServer);
    }

    static class NeoForgeRegistrar implements Network.Registrar {
        PayloadRegistrar registrar;

        public NeoForgeRegistrar(PayloadRegistrar registrar) {
            this.registrar = registrar;
        }

        @Override
        public <T extends HandleablePayload> void register(HandleablePayload.Type<T> type, StreamCodec<? super RegistryFriendlyByteBuf, T> codec, boolean isServer) {
            if (isServer) {
                registrar.playToServer(type, codec, (payload, ctx) -> ctx.enqueueWork(() -> payload.handle(ctx.player())));
            } else {
                registrar.playToClient(type, codec, (payload, ctx) -> ctx.enqueueWork(() -> payload.handle(ctx.player())));
            }
        }
    }
}
