package com.ancientkira.mca.entity.ai;

import com.ancientkira.mca.entity.VillagerLike;
import com.ancientkira.mca.entity.ai.brain.VillagerBrain;
import net.minecraft.core.UUIDUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Mob;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

public class Memories {

    private final UUID playerUUID;
    private final VillagerBrain<?> brain;
    private int hearts;
    private int interactionFatigue;
    private DialogueType dialogueType;
    private long lastSeen;

    public Memories(VillagerBrain<?> brain, long time, UUID uuid) {
        this.brain = brain;
        playerUUID = uuid;
        dialogueType = DialogueType.UNASSIGNED;
        lastSeen = time / 24000L;
    }

    public static <E extends Mob & VillagerLike<E>> Memories fromCNBT(E villager, @Nullable CompoundTag tag) {
        if (tag == null || tag.isEmpty()) {
            return null;
        }

        UUID playerUuid = tag.read("playerUUID", UUIDUtil.LENIENT_CODEC).orElse(new UUID(0L, 0L));
        Memories memories = new Memories(villager.getVillagerBrain(), villager.level().getOverworldClockTime(), playerUuid);

        memories.hearts = tag.getInt("hearts").orElse(0);
        memories.interactionFatigue = tag.getInt("interactionFatigue").orElse(0);
        memories.dialogueType = DialogueType.byId(tag.getInt("dialogueType").orElse(0));
        memories.lastSeen = tag.getLong("lastSeen").orElse(0L);

        return memories;
    }

    public UUID getPlayerUUID() {
        return playerUUID;
    }

    public int getHearts() {
        return hearts;
    }

    public void setHearts(int value) {
        this.hearts = value;
        brain.updateMemories(this);
    }

    public void modHearts(int value) {
        setHearts(this.hearts += value);
    }

    public int getInteractionFatigue() {
        return interactionFatigue;
    }

    public void setInteractionFatigue(int value) {
        this.interactionFatigue = value;
        brain.updateMemories(this);
    }

    public void modInteractionFatigue(int value) {
        this.interactionFatigue += value;
        brain.updateMemories(this);
    }

    public DialogueType getDialogueType() {
        return dialogueType;
    }

    public void setDialogueType(DialogueType dialogueType) {
        this.dialogueType = dialogueType;
        brain.updateMemories(this);
    }

    public long getLastSeen() {
        return lastSeen;
    }

    public void setLastSeen(int lastSeen) {
        this.lastSeen = lastSeen;
        brain.updateMemories(this);
    }

    public CompoundTag toCNBT() {
        CompoundTag nbt = new CompoundTag();

        nbt.putString("playerUUID", playerUUID.toString());
        nbt.putInt("hearts", hearts);
        nbt.putInt("interactionFatigue", interactionFatigue);
        nbt.putInt("dialogueType", dialogueType.ordinal());
        nbt.putLong("lastSeen", lastSeen);

        return nbt;
    }

}
