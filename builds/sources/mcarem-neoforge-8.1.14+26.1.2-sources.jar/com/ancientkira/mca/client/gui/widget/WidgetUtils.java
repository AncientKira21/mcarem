package com.ancientkira.mca.client.gui.widget;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import com.ancientkira.mca.client.gui.PreviewEntityAnimation;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.gui.screens.inventory.tooltip.DefaultTooltipPositioner;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Matrix3x2fStack;

import java.util.List;

// FIXME: 1.20 loses the DrawableHelper attachment, determine if DrawContext can replace this
public class WidgetUtils {
    public static void drawBuildingIcon(GuiGraphicsExtractor context, Identifier texture, int x, int y, int u, int v) {
        Matrix3x2fStack matrices = context.pose();
        matrices.pushMatrix();
        matrices.translate(x - 6.6f, y - 6.6f);
        matrices.scale(0.66f, 0.66f);
        context.blit(RenderPipelines.GUI_TEXTURED, texture, 0, 0, u, v, 20, 20, 256, 256);
        matrices.popMatrix();
    }

    public static void drawRectangle(GuiGraphicsExtractor context, int x0, int y0, int x1, int y1, int color) {
        context.fill(x0 + 1, y0, x1, y0 + 1, color);
        context.fill(x1 - 1, y0 + 1, x1, y1, color);
        context.fill(x0, y1 - 1, x1 - 1, y1, color);
        context.fill(x0, y0, x0 + 1, y1 - 1, color);
    }

    public static void drawTexturedQuad(GuiGraphicsExtractor context, Identifier texture, float x0, float x1, float y0, float y1, float u0, float u1, float v0, float v1) {
        context.blit(texture, Math.round(x0), Math.round(y0), Math.round(x1), Math.round(y1), u0, u1, v0, v1);
    }

    public static void drawTexturedQuad(GuiGraphicsExtractor context, Identifier texture, float x0, float x1, float y0, float y1, float u0, float u1, float v0, float v1, int color) {
        int width = Math.round(x1 - x0);
        int height = Math.round(y1 - y0);
        context.blit(RenderPipelines.GUI_TEXTURED, texture, Math.round(x0), Math.round(y0), u0 * 64.0f, v0 * 64.0f, width, height, Math.round((u1 - u0) * 64.0f), Math.round((v1 - v0) * 64.0f), 64, 64, color);
    }

    public static void drawTooltip(GuiGraphicsExtractor context, Font font, Component text, int x, int y) {
        drawTooltip(context, font, List.of(text), x, y);
    }

    public static void drawTooltip(GuiGraphicsExtractor context, Font font, List<Component> text, int x, int y) {
        List<FormattedCharSequence> lines = text.stream().map(Component::getVisualOrderText).toList();
        List<ClientTooltipComponent> components = lines.stream().map(ClientTooltipComponent::create).toList();
        context.tooltip(font, components, x, y, DefaultTooltipPositioner.INSTANCE, null);
    }

    /**
     * The same as the Inventory function but with negative Z
     */
    public static void drawBackgroundEntity(GuiGraphicsExtractor context, int x, int y, int size, float mouseX, float mouseY, LivingEntity entity) {
        PreviewEntityAnimation.withPreviewTime(entity, () -> {
            InventoryScreen.extractEntityInInventoryFollowsMouse(
                    context,
                    x - size,
                    y - size,
                    x + size,
                    y + size,
                    size,
                    0.0f,
                    mouseX,
                    mouseY,
                    entity
            );
            return null;
        });
    }
}
