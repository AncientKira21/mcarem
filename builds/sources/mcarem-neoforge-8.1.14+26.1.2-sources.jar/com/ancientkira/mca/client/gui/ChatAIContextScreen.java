package com.ancientkira.mca.client.gui;

import com.ancientkira.mca.MCA;
import com.ancientkira.mca.client.gui.widget.TooltipButtonWidget;
import com.ancientkira.mca.network.Network;
import com.ancientkira.mca.network.c2s.ChatAIContextUpdateRequest;
import com.ancientkira.mca.network.s2c.ChatAIContextResponse;
import com.ancientkira.mca.util.compat.ButtonWidget;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;

import java.net.URI;
import java.util.EnumMap;
import java.util.Map;

import static com.ancientkira.mca.entity.VillagerEntityMCA.MAX_NICKNAME_LENGTH;
import static com.ancientkira.mca.network.c2s.ChatAIContextUpdateRequest.MAX_PROMPT_LENGTH;

public class ChatAIContextScreen extends Screen {
    private static final int CONTEXT_TEXT_COLOR = 0xD0D0D0;

    private final ChatAIContextResponse context;
    private final Map<Tab, String> prompts = new EnumMap<>(Tab.class);
    private Tab selectedTab = Tab.VILLAGER;
    private MultiLineEditBox promptField;
    private EditBox nicknameField;
    private String nickname;

    public ChatAIContextScreen(ChatAIContextResponse context) {
        super(Component.translatable("gui.chat_ai_context.title"));

        this.context = context;

        prompts.put(Tab.VILLAGER, context.villagerPrompt());
        prompts.put(Tab.PLAYER, context.playerPrompt());
        prompts.put(Tab.VILLAGE, context.villagePrompt());
        prompts.put(Tab.WORLD, context.worldPrompt());

        nickname = context.villagerNickname();

        if (!selectedTab.available(context)) {
            selectedTab = Tab.PLAYER;
        }
    }

    @Override
    protected void init() {
        clearWidgets();

        int left = width / 2 - 150;
        int top = height / 2 - 120;

        int x = left + 12;
        for (Tab tab : Tab.values()) {
            ButtonWidget button = addRenderableWidget(new ButtonWidget(x, top + 30, 67, 20,
                    Component.translatable(tab.translationKey), ignored -> selectTab(tab)));
            button.active = tab != selectedTab && tab.available(context);
            button.setAlpha(tab.available(context) ? 1.0f : 0.25f);
            x += 70;
        }

        // Help button
        addRenderableWidget(new TooltipButtonWidget(left + 270, top + 6, 18, 18,
                Component.literal("?"), Component.translatable("gui.chat_ai_context.help.tooltip"), ignored -> openHelp()));

        // Prompt
        nicknameField = null;
        int promptY = top + 70;
        int promptHeight = 128;
        if (selectedTab == Tab.VILLAGER) {
            addRenderableWidget(new StringWidget(
                    left + 12,
                    top + 70,
                    50,
                    15,
                    Component.translatable("gui.chat_ai_context.nickname").withColor(CONTEXT_TEXT_COLOR),
                    font
            ));

            nicknameField = addRenderableWidget(new EditBox(font, left + 62, top + 70, 226, 15,
                    Component.translatable("gui.chat_ai_context.nickname_placeholder")));
            nicknameField.setMaxLength(MAX_NICKNAME_LENGTH);
            nicknameField.setTextColor(CONTEXT_TEXT_COLOR);
            nicknameField.setHint(
                    Component.translatable("gui.chat_ai_context.nickname_placeholder")
                            .withColor(0x808080)
            );
            nicknameField.setValue(nickname);

            promptY += 20;
            promptHeight -= 20;
        }
        promptField = addRenderableWidget(MultiLineEditBox.builder().setX(left + 12).setY(promptY)
                .setPlaceholder(Component.translatable("gui.chat_ai_context.placeholder"))
                .build(font, 276, promptHeight, Component.translatable("gui.chat_ai_context.prompt")));
        promptField.setCharacterLimit(MAX_PROMPT_LENGTH);
        promptField.setValue(prompts.get(selectedTab));

        // Close
        addRenderableWidget(new ButtonWidget(width / 2 - 44, top + 205, 88, 20,
                Component.translatable("gui.chat_ai_context.close"), ignored -> onClose()));
    }

    private void selectTab(Tab tab) {
        if (!tab.available(context) || tab == selectedTab) {
            return;
        }
        saveCurrent();
        selectedTab = tab;
        init();
    }

    private void saveCurrent() {
        if (promptField == null || !selectedTab.available(context)) {
            return;
        }

        String prompt = promptField.getValue();
        String updatedNickname = nicknameField == null ? nickname : nicknameField.getValue().strip();
        if (prompt.equals(prompts.get(selectedTab)) && updatedNickname.equals(nickname)) {
            return;
        }

        prompts.put(selectedTab, prompt);
        nickname = updatedNickname;
        Network.sendToServer(new ChatAIContextUpdateRequest(
                selectedTab.target, context.dimension(), context.villagerUuid(), context.villageId(), prompt, nickname
        ));
    }

    @Override
    public void onClose() {
        saveCurrent();
        super.onClose();
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(graphics, mouseX, mouseY, partialTick);

        int left = width / 2 - 150;
        int top = height / 2 - 120;

        graphics.fill(0, 0, width, height, 0x90000000);
        graphics.fill(left, top, left + 300, top + 232, 0xE0181B20);
        graphics.fill(left + 1, top + 1, left + 299, top + 231, 0xE02A2E36);

        // Title
        graphics.centeredText(font, title, width / 2, top + 12, 0xFFFFFF);

        // Name
        graphics.text(font, Component.translatable(selectedTab.translationKey).append(": ").append(selectedTab.name(context)), left + 12, top + 59, CONTEXT_TEXT_COLOR);
    }

    private void openHelp() {
        try {
            Util.getPlatform().openUri(URI.create("https://github.com/Luke100000/minecraft-comes-alive/wiki/GPT3-based-conversations"));
        } catch (Exception e) {
            MCA.LOGGER.error("Unable to open ChatAI help", e);
        }
    }

    private enum Tab {
        VILLAGER(ChatAIContextUpdateRequest.Target.VILLAGER, "gui.chat_ai_context.villager") {
            @Override
            boolean available(ChatAIContextResponse context) {
                return context.hasVillager();
            }

            @Override
            String name(ChatAIContextResponse context) {
                return context.villagerName();
            }
        },
        PLAYER(ChatAIContextUpdateRequest.Target.PLAYER, "gui.chat_ai_context.player") {
            @Override
            boolean available(ChatAIContextResponse context) {
                return true;
            }

            @Override
            String name(ChatAIContextResponse context) {
                return context.playerName();
            }
        },
        VILLAGE(ChatAIContextUpdateRequest.Target.VILLAGE, "gui.chat_ai_context.village") {
            @Override
            boolean available(ChatAIContextResponse context) {
                return context.hasVillage();
            }

            @Override
            String name(ChatAIContextResponse context) {
                return context.villageName();
            }
        },
        WORLD(ChatAIContextUpdateRequest.Target.WORLD, "gui.chat_ai_context.world") {
            @Override
            boolean available(ChatAIContextResponse context) {
                return true;
            }

            @Override
            String name(ChatAIContextResponse context) {
                return Component.translatable("gui.chat_ai_context.world_name").getString();
            }
        };

        private final ChatAIContextUpdateRequest.Target target;
        private final String translationKey;

        Tab(ChatAIContextUpdateRequest.Target target, String translationKey) {
            this.target = target;
            this.translationKey = translationKey;
        }

        abstract boolean available(ChatAIContextResponse context);

        abstract String name(ChatAIContextResponse context);
    }
}
