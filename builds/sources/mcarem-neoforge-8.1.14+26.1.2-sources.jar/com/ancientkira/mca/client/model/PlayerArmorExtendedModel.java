package com.ancientkira.mca.client.model;

import com.google.common.collect.ImmutableList;
import com.ancientkira.mca.client.render.VillagerStateHolder;
import com.ancientkira.mca.entity.ai.relationship.AgeState;
import com.ancientkira.mca.entity.ai.relationship.VillagerDimensions;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.world.entity.LivingEntity;

import static com.ancientkira.mca.client.model.VillagerEntityBaseModelMCA.BREASTS;

public class PlayerArmorExtendedModel<T extends LivingEntity> extends HumanoidModel<HumanoidRenderState> implements CommonVillagerModel<T> {
    public final ModelPart breasts;

    final VillagerDimensions.Mutable dimensions = new VillagerDimensions.Mutable(AgeState.ADULT);
    float breastSize;

    public PlayerArmorExtendedModel(ModelPart root) {
        super(root);
        this.breasts = VillagerEntityBaseModelMCA.getChildOrEmpty(root, BREASTS);
    }

    public void copyPropertiesTo(HumanoidModel<?> target) {
        if (target instanceof PlayerEntityExtendedModel<?> playerTarget) {
            copyAttributes(playerTarget);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void copyAttributes(PlayerEntityExtendedModel<?> target) {
        CommonVillagerModel.copyPartState(target.head, head);
        CommonVillagerModel.copyPartState(target.hat, hat);
        CommonVillagerModel.copyPartState(target.body, body);
        CommonVillagerModel.copyPartState(target.leftArm, leftArm);
        CommonVillagerModel.copyPartState(target.rightArm, rightArm);
        CommonVillagerModel.copyPartState(target.leftLeg, leftLeg);
        CommonVillagerModel.copyPartState(target.rightLeg, rightLeg);
        copyCommonAttributes((CommonVillagerModel) target);

        target.breasts.visible = breasts.visible;
        CommonVillagerModel.copyPartState(target.breasts, breasts);
    }

    @Override
    public ModelPart getBreastPart() {
        return breasts;
    }

    @Override
    public ModelPart getBodyPart() {
        return body;
    }

    @Override
    public Iterable<ModelPart> getCommonHeadParts() {
        return ImmutableList.of(head);
    }

    @Override
    public Iterable<ModelPart> getCommonBodyParts() {
        return ImmutableList.of(body, rightArm, leftArm, rightLeg, leftLeg);
    }

    @Override
    public Iterable<ModelPart> getBreastParts() {
        return ImmutableList.of(breasts);
    }

    @Override
    public VillagerDimensions.Mutable getDimensions() {
        return dimensions;
    }

    @Override
    public float getBreastSize() {
        return breastSize;
    }

    @Override
    public void setBreastSize(float breastSize) {
        this.breastSize = breastSize;
    }


    @Override
    public void setupAnim(HumanoidRenderState state) {
        boolean showBody = true;
        boolean showHat = true;
        if (state instanceof AvatarRenderState avatarState) {
            showBody = !avatarState.isSpectator;
            showHat = avatarState.showHat;
        }

        head.visible = showBody;
        hat.visible = showHat;
        body.visible = showBody;
        breasts.visible = showBody;
        leftArm.visible = showBody;
        rightArm.visible = showBody;
        leftLeg.visible = showBody;
        rightLeg.visible = showBody;
        super.setupAnim(state);

        if (state instanceof VillagerStateHolder holder) {
            var visuals = holder.mca$getVisuals();
            if (visuals != null) {
                applyVillagerDimensions(visuals);
            }
            if (holder.mca$getHumanoidModelPose() != null) {
                holder.mca$getHumanoidModelPose().applyTo(this);
            }
        }
    }
}
