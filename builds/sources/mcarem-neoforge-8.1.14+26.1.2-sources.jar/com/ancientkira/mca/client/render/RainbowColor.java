package com.ancientkira.mca.client.render;

import net.minecraft.client.color.ColorLerper;
import net.minecraft.world.item.DyeColor;

public final class RainbowColor {
    public static final int CYCLE_DURATION = 25 * DyeColor.values().length;

    private RainbowColor() {
    }

    public static int sheep(float tick) {
        return ColorLerper.getLerpedColor(ColorLerper.Type.SHEEP, tick);
    }
}
