package com.ancientkira.mca.client.render.layer;

import com.ancientkira.mca.MCA;
import com.ancientkira.mca.client.gui.immersive_library.SkinCache;
import com.ancientkira.mca.client.render.VillagerVisuals;
import com.ancientkira.mca.util.ImmersiveLibraryIds;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.resources.Identifier;

public class ClothingLayer<S extends HumanoidRenderState, M extends HumanoidModel<S>> extends VillagerLayer<S, M> {
    private final String variant;

    public ClothingLayer(RenderLayerParent<S, M> renderer, M model, String variant) {
        super(renderer, model);
        this.variant = variant;
    }

    @Override
    public Identifier getSkin(S state) {
        return getSkin(VillagerVisuals.require(state));
    }

    public Identifier getSkin(VillagerVisuals visuals) {
        String identifier = visuals.clothes();
        if (MCA.isBlankString(identifier)) {
            return null;
        }
        String v = visuals.burned() ? "burnt" : variant;
        var contentId = ImmersiveLibraryIds.contentId(identifier);
        if (contentId.isPresent()) {
            return SkinCache.getTextureIdentifier(contentId.getAsInt());
        }
        return cached(identifier + v, clothes -> {
            Identifier id = Identifier.parse(visuals.clothes());

            Identifier idNew = Identifier.fromNamespaceAndPath(id.getNamespace(), id.getPath().replace("normal", v));
            if (canUse(idNew)) {
                return idNew;
            }

            return id;
        });
    }
}
